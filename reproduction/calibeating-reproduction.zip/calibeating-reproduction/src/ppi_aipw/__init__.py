"""Mean-estimation entry point used by the paper experiments."""
from ._api import mean_inference
